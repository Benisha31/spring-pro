package com.dsrc.project.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cancellation")
public class Cancellation {
	@Column(name="custid")
private String custId;
@Id
@Column(name="bookingid")

private int bookingId;
@Column(name="scheduleid")

private int scheduleId;
@Column(name="dateofcancelling")

private String dateOfCancelling;
@Column(name="numofseatscancelled")

private int numOfSeatsCancelled;
@Column(name="seatno")

private String seatNo;

public Cancellation(String custId, int bookingId, int scheduleId, String dateOfCancelling, int numOfSeatsCancelled,
		String seatNo) {
	//super();
	this.custId = custId;
	this.bookingId = bookingId;
	this.scheduleId = scheduleId;
	this.dateOfCancelling = dateOfCancelling;
	this.numOfSeatsCancelled = numOfSeatsCancelled;
	this.seatNo = seatNo;
}
public Cancellation() {
	//super();
}
@Override
public String toString() {
	return "Cancellation [custId=" + custId + ", bookingId=" + bookingId + ", scheduleId=" + scheduleId
			+ ", dateOfCancelling=" + dateOfCancelling + ", numOfSeatsCancelled=" + numOfSeatsCancelled + ", seatNo="
			+ seatNo + "]";
}
public String getCustId() {
	return custId;
}
public void setCustId(String custId) {
	this.custId = custId;
}
public int getBookingId() {
	return bookingId;
}
public void setBookingId(int bookingId) {
	this.bookingId = bookingId;
}
public int getScheduleId() {
	return scheduleId;
}
public void setScheduleId(int scheduleId) {
	this.scheduleId = scheduleId;
}
public String getDateOfCancelling() {
	return dateOfCancelling;
}
public void setDateOfCancelling(String dateOfCancelling) {
	this.dateOfCancelling = dateOfCancelling;
}
public int getNumOfSeatsCancelled() {
	return numOfSeatsCancelled;
}
public void setNumOfSeatsCancelled(int numOfSeatsCancelled) {
	this.numOfSeatsCancelled = numOfSeatsCancelled;
}
public String getSeatNo() {
	return seatNo;
}
public void setSeatNo(String seatNo) {
	this.seatNo = seatNo;
}
}
