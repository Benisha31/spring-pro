package com.dsrc.project.bookingServices;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dsrc.project.beans.Cancellation;
import com.dsrc.project.beans.Customers;
import com.dsrc.project.beans.Login;
import com.dsrc.project.beans.Reservation;
import com.dsrc.project.beans.Schedule;
import com.dsrc.project.dao.ScheduleRepository;

@Service
@Transactional
public class ScheduleServiceImplements implements ScheduleService {

	@Autowired
	private ScheduleRepository scheduleRepository;
		
	@Override
	public List<Schedule> getSchedule() {
		return scheduleRepository.getSchedule();
	}

    @Override
	public boolean addSchedule(Schedule schedule) {
		return scheduleRepository.addSchedule(schedule);
	}

	@Override
	public boolean deleteSchedule(Integer id) {
		return scheduleRepository.deleteSchedule(id);
	}

	@Override
	public boolean editSchedule(Schedule schedule) {
		return  scheduleRepository.editSchedule(schedule);
	}

	@Override
	public List<Schedule> searchSchedule(String no) {
		return scheduleRepository.searchSchedule(no);
	}

	@Override
	public boolean getCustomer(Login log) {
		
		return scheduleRepository.getCustomer(log);
	}

	@Override
	public List<Cancellation> getCancellation() {
		return scheduleRepository.getCancellation();
	}

	@Override
	public List<Reservation> getReservation() {
		// TODO Auto-generated method stub
		return scheduleRepository.getReservation();
	}

	@Override
	public List<Customers> getCustomers() {
		// TODO Auto-generated method stub
		return scheduleRepository.getCustomers();
	}

	
}
