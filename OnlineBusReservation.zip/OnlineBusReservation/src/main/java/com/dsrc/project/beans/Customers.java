package com.dsrc.project.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customers")
public class Customers 
{
@Id
@Column(name="custid")
private String custId;
@Column(name="password")
private String password;
@Column(name="fullname")
private String fullName;
@Column(name="age")
private int age;
@Column(name="gender")
private String gender;
@Column(name="email")
private String email;
@Column(name="address")
private String address;
@Column(name="city")
private String city;
@Column(name="phoneno")
private String phoneNo;


public String getCustId() {
	return custId;
}
public void setCustId(String custId) {
	this.custId = custId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getFullName() {
	return fullName;
}
public void setFullName(String fullName) {
	this.fullName = fullName;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getPhoneNo() {
	return phoneNo;
}
public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;
}

public Customers(String custId, String password, String fullName, int age, String gender, String email, String address,
		String city, String phoneNo) {
	this.custId = custId;
	this.password = password;
	this.fullName = fullName;
	this.age = age;
	this.gender = gender;
	this.email = email;
	this.address = address;
	this.city = city;
	this.phoneNo = phoneNo;
}

public Customers() {}

}
