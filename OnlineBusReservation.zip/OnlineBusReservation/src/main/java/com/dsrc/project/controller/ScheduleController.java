package com.dsrc.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dsrc.project.beans.Cancellation;
import com.dsrc.project.beans.Customers;
import com.dsrc.project.beans.Login;
import com.dsrc.project.beans.Reservation;
import com.dsrc.project.beans.Schedule;
import com.dsrc.project.bookingServices.ScheduleService;


@RestController
@RequestMapping("/Schedule")
@CrossOrigin(origins="http://localhost:4200",allowedHeaders="*")
public class ScheduleController  {
	 @Autowired
     public ScheduleService scheduleService;
   
	 @GetMapping("/getSchedule")
	public List<Schedule> getSchedule() {
			return scheduleService.getSchedule();		
	    }   
    @PostMapping("/addSchedule")
    public boolean addSchedule(@RequestBody Schedule Schedule) {
		return scheduleService.addSchedule(Schedule);   	
    }
    
    @DeleteMapping("/deleteSchedule/{scheduleId}")
	public boolean deleteSchedule(@PathVariable("scheduleId") int id) {
    	scheduleService.deleteSchedule(id);
		return true;
   }
    @PutMapping("/editSchedule")
    public boolean editSchedule(@RequestBody Schedule Schedule) {
		return scheduleService.editSchedule(Schedule);   	
    }
    @GetMapping("/searchSchedule/{busNo}")
	public List<Schedule> searchSchedule(@PathVariable("busNo") String no) {
			return scheduleService.searchSchedule(no);		
	    }
    @PostMapping("/getCustomer")
	public boolean getCustomer(@RequestBody Login log)
	{
		return scheduleService.getCustomer(log);
		
	}
    @GetMapping("/getCancellation")
  	public List<Cancellation> getCancellation()
  	{
  		return scheduleService.getCancellation();
  		
  	}
    @GetMapping("/getReservation")
  	public List<Reservation> getReservation()
  	{
  		return scheduleService.getReservation();
  		
  	}
    @GetMapping("/getCustomers")
  	public List<Customers> getCustomers()
  	{
  		return scheduleService.getCustomers();
  		
  	}
}
