package com.dsrc.project.bookingServices;

import java.util.List;

import com.dsrc.project.beans.Cancellation;
import com.dsrc.project.beans.Customers;
import com.dsrc.project.beans.Login;
import com.dsrc.project.beans.Reservation;
import com.dsrc.project.beans.Schedule;

public interface ScheduleService {

	public boolean addSchedule(Schedule schedule);
    public List<Schedule> getSchedule();
	public boolean deleteSchedule(Integer id);
	public boolean editSchedule(Schedule schedule);
	public List<Schedule> searchSchedule(String no);
	public boolean getCustomer(Login log);
	public List<Cancellation> getCancellation();
	public List<Reservation> getReservation();
	public List<Customers> getCustomers();




}
