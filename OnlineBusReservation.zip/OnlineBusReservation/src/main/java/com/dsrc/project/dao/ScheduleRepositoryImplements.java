package com.dsrc.project.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.dsrc.project.beans.Cancellation;
import com.dsrc.project.beans.Customers;
import com.dsrc.project.beans.Login;
import com.dsrc.project.beans.Reservation;
import com.dsrc.project.beans.Schedule;


@Repository
public class ScheduleRepositoryImplements implements ScheduleRepository{

	@PersistenceContext	
	private EntityManager entityManager;	
	
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public boolean addSchedule(Schedule schedule) {
		entityManager.persist(schedule);
		return true;
		
	}

	@Override
	public List<Schedule> getSchedule() {

		List<Schedule> list = entityManager.createQuery("from Schedule",Schedule.class).getResultList();
 		return list;
	}

	@Override
	public boolean deleteSchedule(Integer id) {
		 
		Schedule schedule=entityManager.find(Schedule.class, id);
		entityManager.remove(schedule);	
		return true;
	}

	@Override
	public boolean editSchedule(Schedule schedule) {
		entityManager.createQuery("update Schedule set busNo=:a,source=:b, destination=:c, dateScheduled=:d,timeScheduled=:e,availSeats=:f, fare=:g where scheduleId=:h")
                  
                  .setParameter("a", schedule.getBusNo())
                  .setParameter("b", schedule.getSource())
                  .setParameter("c", schedule.getDestination())
                  .setParameter("d", schedule.getDateScheduled())
                  .setParameter("e", schedule.getTimeScheduled())
                  .setParameter("f", schedule.getAvailSeats())
                  .setParameter("g", schedule.getFare())
                  .setParameter("h", schedule.getScheduleId())
                  .executeUpdate();
          
          return true;
	}

	@Override
	public List<Schedule> searchSchedule(String no) {
		List<Schedule> list = entityManager.createQuery("from Schedule where busNo=:a",Schedule.class)
				.setParameter("a", no).getResultList();
		return list;
	}

	
	@Override
	public boolean getCustomer(Login log) {
		boolean res=false;
		System.out.println(log.getCustId());
		List l= entityManager.createQuery("FROM Login where custId=:id and password=:pass and role=:roles",Login.class)
				.setParameter("id",log.getCustId())
				.setParameter("pass",log.getPassword())
				.setParameter("roles", log.getRole())
				.getResultList();
		if(l.size()>0) {
			return true;
		}
		
		return false;

	}

	@Override
	public List<Cancellation> getCancellation() {
		List<Cancellation> list = entityManager.createQuery("from Cancellation",Cancellation.class).getResultList();
 		return list;
	}

	@Override
	public List<Reservation> getReservation() {
		List<Reservation> list = entityManager.createQuery("from Reservation",Reservation.class).getResultList();
		return list;
	}

	@Override
	public List<Customers> getCustomers() {
		List<Customers> list = entityManager.createQuery("from Customers where custId!=:a",Customers.class)
				.setParameter("a", "admin").getResultList();
		return list;
	}
	
}