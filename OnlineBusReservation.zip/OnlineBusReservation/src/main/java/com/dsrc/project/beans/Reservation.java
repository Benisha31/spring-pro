package com.dsrc.project.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="reservation")
public class Reservation {
	@Id
	@Column(name="custid")
	private String custId;
	@Column(name="bookingid")

    private int bookingId;
	@Column(name="dateofbooking")

    private String dateOfBooking;
	@Column(name="scheduleid")

    private int scheduleId;
	@Column(name="numofseatswanted")

    private int numofseatswanted;
	@Column(name="seatno")

    private int seatNo;
	public Reservation() {
		
	}
	public Reservation(String custId, int bookingId, String dateOfBooking, int scheduleId, int numofseatswanted,
			int seatNo) {
		this.custId = custId;
		this.bookingId = bookingId;
		this.dateOfBooking = dateOfBooking;
		this.scheduleId = scheduleId;
		this.numofseatswanted = numofseatswanted;
		this.seatNo = seatNo;
	}
	@Override
	public String toString() {
		return "Reservation [custId=" + custId + ", bookingId=" + bookingId + ", dateOfBooking=" + dateOfBooking
				+ ", scheduleId=" + scheduleId + ", numofseatswanted=" + numofseatswanted + ", seatNo=" + seatNo + "]";
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getDateOfBooking() {
		return dateOfBooking;
	}
	public void setDateOfBooking(String dateOfBooking) {
		this.dateOfBooking = dateOfBooking;
	}
	public int getScheduleId() {
		return scheduleId;
	}
	public void setScheduleId(int scheduleId) {
		this.scheduleId = scheduleId;
	}
	public int getNumofseatswanted() {
		return numofseatswanted;
	}
	public void setNumofseatswanted(int numofseatswanted) {
		this.numofseatswanted = numofseatswanted;
	}
	public int getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}
}
